---
id: 55
---

#### Toggle Debug Print

Given you have admin rights, you can use the command `mysql:debug` which flips interally the value
for `mysql_debug` to `1` or `0`, so it enables you to turn on the debug prints
to the console or a file, or both given your settings for `mysql_debug_output`.
