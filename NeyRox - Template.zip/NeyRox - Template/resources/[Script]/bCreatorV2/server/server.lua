ESX = nil

CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Wait(0)
    end
end)
RegisterNetEvent('flCore:CreatePlayer')
AddEventHandler('flCore:CreatePlayer', function(Creator)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    MySQL.Async.execute("UPDATE users SET firstname = @prenom, lastname = @nom, dateofbirth = @dob, sex = @sex, height = @height WHERE identifier = @identifier", {
        ["@identifier"] = xPlayer.identifier,
        ["@prenom"] = Creator.firstname,
        ["@nom"] = Creator.lastname,
        ["@dob"] = Creator.age,
        ["@sex"] = Creator.sexe,
        ["@height"] = Creator.height
    }, function()
        print("📌 | Nouvel enregistrement d'identity ("..GetPlayerName(xPlayer.source)..")\n- Nom : "..Creator.lastname.."\n- Prénom : "..Creator.firstname)
    end)

    if Creator.starter.name == "legal" then
        xPlayer.addMoney(1000)
        xPlayer.addAccountMoney('bank', 2500)
        xPlayer.addInventoryItem("eau", 5)
        xPlayer.addInventoryItem("pain", 5)
    elseif Creator.starter.name == "illegal" then
        xPlayer.addAccountMoney('black_money', 2500)
        xPlayer.addAccountMoney('bank', 1000)
        xPlayer.addInventoryItem("weapon_bat", 5)
    end
end)
