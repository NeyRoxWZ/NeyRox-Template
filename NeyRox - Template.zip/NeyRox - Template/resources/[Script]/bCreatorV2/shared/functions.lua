function KeyboardInput(TextEntry)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", "", "", "", "", 1000) 
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Wait(0) end
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500) 
        return result
    else
        Wait(500) 
        return nil 
    end
end

function TableCount(tbl, checkCount)
    if not tbl or type(tbl) ~= "table" then
        return not checkCount and 0
    end
    local n = 0
    for k, v in pairs(tbl) do
        n = n + 1
        if checkCount and n >= checkCount then
            return true
        end
    end
    return not checkCount and n
end

function getNilValue(value, type)
    if type == "string" then
        if value == nil then
            return "~r~DÉFINIR~s~"
        else
            return value
        end
    else
        if value == nil then
            return "[~r~DÉFINIR~s~]"
        else
            return "[~g~DÉFINI~s~]"
        end
    end
end

function Starts(String, Start)
    return string.sub(String, 1, string.len(Start)) == Start
end
-------------------------------------------------------

Character = {}
local pedModel = 'mp_m_freemode_01'
function changeGender(sex)
	if sex == 1 then
		Character['sex'] = 0
		pedModel = 'mp_m_freemode_01'
		changeModel(pedModel)
	else
		Character['sex'] = 1
		pedModel = 'mp_f_freemode_01'
		changeModel(pedModel)
	end
end

function changeModel(skin)
    if IsModelInCdimage(GetHashKey(skin)) and IsModelValid(GetHashKey(skin)) then
        RequestModel(GetHashKey(skin))
        while not HasModelLoaded(GetHashKey(skin)) do
            Wait(0)
        end
        SetPlayerModel(PlayerId(), GetHashKey(skin))
        SetPedDefaultComponentVariation(PlayerPedId())

        if skin == 'mp_m_freemode_01' then
            SetPedComponentVariation(PlayerPedId(), 3, 15, 0, 2) -- arms
            SetPedComponentVariation(PlayerPedId(), 11, 15, 0, 2) -- torso
            SetPedComponentVariation(PlayerPedId(), 8, 15, 0, 2) -- tshirt
            SetPedComponentVariation(PlayerPedId(), 4, 61, 4, 2) -- pants
            SetPedComponentVariation(PlayerPedId(), 6, 34, 0, 2) -- shoes

            Character['arms'] = 15
            Character['torso_1'] = 15
            Character['tshirt_1'] = 15
            Character['pants_1'] = 61
            Character['pants_2'] = 4
            Character['shoes_1'] = 34
            Character['glasses_1'] = 0
        elseif skin == 'mp_f_freemode_01' then
            SetPedComponentVariation(PlayerPedId(), 3, 15, 0, 2) -- arms
            SetPedComponentVariation(PlayerPedId(), 11, 5, 0, 2) -- torso
            SetPedComponentVariation(PlayerPedId(), 8, 15, 0, 2) -- tshirt
            SetPedComponentVariation(PlayerPedId(), 4, 57, 0, 2) -- pants
            SetPedComponentVariation(PlayerPedId(), 6, 35, 0, 2) -- shoes

            Character['arms'] = 15
            Character['torso_1'] = 5
            Character['tshirt_1'] = 15
            Character['pants_1'] = 57
            Character['pants_2'] = 0
            Character['shoes_1'] = 35
            Character['glasses_1'] = -1
        end
        SetModelAsNoLongerNeeded(GetHashKey(skin))
    end
end

-------------------------------------------------------