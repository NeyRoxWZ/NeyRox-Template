ESX = nil

CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Wait(0)
    end
end)




local Valid = false
local Creator = {
    firstname = nil,
    lastname = nil,
    sexe = nil,
    age = nil,
    height = nil,
    starter = nil,
    spawn = nil,
    skinSpawn = nil,

    face = {
        index = 1,
        items = {},
    },
    -------------------------------------------------------
    sex = {
        index = 1,
        items = {"Homme", "Femme"}
    },
    -------------------------------------------------------
    hair_1 = {
        index = 1,
        items = {},
    },
    hair_color = {
        primary = { 1, 1 },
        secondary = { 1, 1 }
    },
    -------------------------------------------------------
    beard_1 = {
        index = 1,
        items = {},
    },
    beard_2 = {
        percentage = 1.0,
    },
    beard_3 = {
        primary = { 1, 1 },
        secondary = { 1, 1 }
    },
    -------------------------------------------------------
    skin = {
        index = 1,
        items = {}
    },
    -------------------------------------------------------
    makeup_1 = {
        index = 1,
        items = {},
    },
    makeup_2 = {
        percentage = 1.0,
    },
    makeup_3 = {
        primary = { 1, 1 },
        secondary = { 1, 1 },
        third = {1, 1}
    },
    -------------------------------------------------------
    lipstick_1 = {
        index = 1,
        items = {},
    },
    lipstick_2 = {
        percentage = 1.0,
    },
    lipstick_3 = {
        primary = { 1, 1 },
        secondary = { 1, 1 }
    },

}
local Spawn = {
    ['Aéroport Sud'] = {tp1 = vector3(-1045.28, -2750.89, 21.36) , tp2 = vector3(-1037.26, -2738.87, 20.17)},
    ['Aéroport Nord'] = {tp1 = vector3(1727.79, 3321.41, 41.22), tp2 = vector3(1734.66, 3295.02, 41.2)},
    ['Poste de Police'] = {tp1 = vector3(-1092.06, -809.24, 19.27), tp2 = vector3(-1100.64, -799.11, 18.56)},
    ['Métro'] = {tp1 = vector3(-818.56, -108.02, 27.95), tp2 = vector3(-802.48, -99.37, 37.55)}
}

local Skin = {
    ["Tenue d'homme d'affaire"] = {
        Male = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 111, torso_2 = 3,
            arms = 12,
            chain_1 = 0, chain_2 = 0,
            pants_1 = 24, pants_2 = 0,
            bags_1 = 0, bags_2 = 0,
            shoes_1 = 10, shoes_2 = 0,
            helmet_1= -1, helmet_2 = 0,
            ears_1 = 0,     ears_2 = 0
        },
        Female = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 111, torso_2 = 3,
            arms = 12,
            chain_1 = 0, chain_2 = 0,
            pants_1 = 24, pants_2 = 0,
            bags_1 = 0, bags_2 = 0,
            shoes_1 = 10, shoes_2 = 0,
            helmet_1= -1, helmet_2 = 0,
            ears_1 = 0,     ears_2 = 0
        },
    },
    ["Tenue Rue"] = {
        Male = {
            tshirt_1 = 176, tshirt_2 = 0,
            torso_1 = 88, torso_2 = 2,
            arms = 12,
            chain_1 = 0, chain_2 = 0,
            bags_1 = 0, bags_2 = 0,
            pants_1 = 64, pants_2 = 10,
            shoes_1 = 9, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0,
            ears_1 = 0,     ears_2 = 0
        },
        Female = {
            tshirt_1 = 176, tshirt_2 = 0,
            torso_1 = 88, torso_2 = 2,
            arms = 12,
            chain_1 = 0, chain_2 = 0,
            bags_1 = 0, bags_2 = 0,
            pants_1 = 64, pants_2 = 10,
            shoes_1 = 9, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0,
            ears_1 = 0,     ears_2 = 0
        },
    },
    ["Tenue de travail"] = {
        Male = {
            tshirt_1 = 32, tshirt_2 = 0,
            torso_1 = 23, torso_2 = 0,
            arms = 12,
            bags_1 = 0, bags_2 = 0,
            chain_1 = 0, chain_2 = 0,
            pants_1 = 28, pants_2 = 4,
            shoes_1 = 40, shoes_2 = 9,
            helmet_1 = -1, helmet_2 = 0,
            ears_1 = 0,     ears_2 = 0
        },
        Female = {
            tshirt_1 = 32, tshirt_2 = 0,
            torso_1 = 23, torso_2 = 0,
            arms = 12,
            bags_1 = 0, bags_2 = 0,
            chain_1 = 0, chain_2 = 0,
            pants_1 = 28, pants_2 = 4,
            shoes_1 = 40, shoes_2 = 9,
            helmet_1 = -1, helmet_2 = 0,
            ears_1 = 0,     ears_2 = 0
        },
    }
}
AddEventHandler('playerSpawned', function()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
        if skin == nil then
            if NetworkIsPlayerActive(PlayerId()) then
                local ModelSpawn = "mp_m_freemode_01"
                RequestModel(ModelSpawn)
                while not HasModelLoaded(ModelSpawn) do
                    RequestModel(ModelSpawn)
                    Citizen.Wait(0)
                end
                SetPlayerModel(PlayerId(), ModelSpawn)
                ClearPedProp(PlayerId(), 0)
                SetPedComponentVariation(GetPlayerPed(-1), 8, 15, 0, 2)
                SetPedComponentVariation(GetPlayerPed(-1), 4, 21, 0, 2)
                SetPedComponentVariation(GetPlayerPed(-1), 6, 34, 0, 2)
                SetPedComponentVariation(GetPlayerPed(-1), 11, 15, 0, 2)
                SetPedComponentVariation(GetPlayerPed(-1), 3, 15, 0, 2)
            end
            CamCreator()
            OpenMenuCreator()
        else
            TriggerEvent('skinchanger:loadSkin', skin)
        end
    end)
end)
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function OpenMenuCreator()
    local MainMenu = RageUI.CreateMenu('', 'Que voulez-vous faire ?')
    local MainIdentity = RageUI.CreateSubMenu(MainMenu, '', 'Que voulez-vous faire ?')
    local MainSkin = RageUI.CreateSubMenu(MainMenu, '', 'Que voulez-vous faire ?')
    local MainChoose = RageUI.CreateSubMenu(MainSkin, '', 'Que voulez-vous faire ?')
    local MainStarter = RageUI.CreateSubMenu(MainMenu, '', 'Que voulez-vous faire ?')
    local MainSpawn = RageUI.CreateSubMenu(MainMenu, '', 'Que voulez-vous faire ?')
    local MainVetement = RageUI.CreateSubMenu(MainMenu, '', 'Que voulez-vous faire ?')

    GetComponents()

    MainSkin:AddInstructionButton({[1] = GetControlInstructionalButton(0, 73, 0), [2] = "Zoomer en arrière"})
    MainSkin:AddInstructionButton({[1] = GetControlInstructionalButton(0, 79, 0), [2] = "Zoomer en avant"})
    MainSkin:AddInstructionButton({[1] = GetControlInstructionalButton(0, 44, 0), [2] = "Tournée à droite"})
    MainSkin:AddInstructionButton({[1] = GetControlInstructionalButton(0, 51, 0), [2] = "Tournée à gauche"})

    MainSkin.EnableMouse = true
    MainMenu.Closable = false

    MainMenu.Closed = function()
        DestroyCamCreator()
        RageUI.Visible(MainMenu, false)
    end

    RageUI.Visible(MainMenu, not RageUI.Visible(MainMenu))
    CreateThread(function()
        while (MainMenu) do
            Wait(0)

            RageUI.IsVisible(MainMenu, function()
                RageUI.Button("∑ → Crée son identité", nil, {}, true, {}, MainIdentity)
                RageUI.Button("∑ → Crée son personnage", nil, {}, true, {}, MainSkin)
                RageUI.Button("∑ → Choisir son pack de départ", nil, {}, true, { }, MainStarter)
                RageUI.Button("∑ → Choisir son lieu d'atterisage", nil, {}, true, {}, MainSpawn)
                RageUI.Button("∑ → Choisir ses vêtements", nil, {}, true, {}, MainVetement)
                if not Valid then
                    RageUI.Button("∑ → ~g~Valider la création", nil, {}, Creator.firstname ~= nil and Creator.lastname ~= nil and Creator.sexe ~= nil and Creator.age ~= nil and Creator.height ~= nil and Creator.starter ~= {} and Creator.spawn ~= {}, {
                        onSelected = function()
                            Valid = true
                        end
                    })
                else
                    RageUI.Button("∑ → ~g~Valider la création", nil, {RightLabel = "~r~Confirmation"}, true, {
                        RageUI.Info('~p~Family~s~ Life', {'Prénom :', 'Nom :', 'Date de naissance :', 'Sexe :', 'Taille :', 'Lieu atterisage :', 'Pack de départ :', 'Vêtement :'}, {"~p~"..Creator.firstname.."~s~", "~p~"..Creator.lastname, "~p~"..Creator.age.."~s~", "~p~"..Creator.sexe.."~s~", "~p~"..Creator.height.."~s~", "~p~"..Creator.spawn.."~s~", Creator.starter.label.."~s~", "~p~"..Creator.skinSpawn.."~s~"}),
                        onSelected = function()
                            DoScreenFadeOut(3000)
                            Wait(3000)
                            SetEntityCoords(PlayerPedId(), Spawn[Creator.spawn].tp1)
                            RageUI.CloseAll()
                            FreezeEntityPosition(PlayerPedId(), false) 
                            DestroyCamCreator()
                            skinAnim(Spawn[Creator.spawn].tp2)
                            TriggerServerEvent('flCore:CreatePlayer', Creator)
                            DoScreenFadeIn(3000)
                            Wait(3000)
                            ESX.ShowNotification("~p~Family~s~ Life\nBienvenue sur le serveur ! Bon jeu à toi")
                        end
                    })
                end
            end)

            RageUI.IsVisible(MainIdentity, function()
                RageUI.Info('~p~Family~s~ Life', {'Nom de famille :', 'Prénom :', 'Sexe :', 'Date de naissance :', 'Taille du personnage :'}, {getNilValue(Creator.lastname, 'string'), getNilValue(Creator.firstname, 'string'), getNilValue(Creator.sexe, 'string'), getNilValue(Creator.age, 'string'), getNilValue(Creator.height, 'string')})
                RageUI.Button('Nom du personnage', nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onSelected = function()
                        Creator.lastname = KeyboardInput('Indiquez le nom de votre personnage')
                    end
                })
                RageUI.Button('Prénom du personnage', nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onSelected = function()
                        Creator.firstname = KeyboardInput('Indiquez le nom de votre personnage')
                    end
                })
                RageUI.Button('Sexe du personnage', nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onSelected = function()
                        Creator.sexe = KeyboardInput('Indiquez le nom de votre personnage')
                    end
                })
                RageUI.Button('Date de naissance du personnage', nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onSelected = function()
                        Creator.age = KeyboardInput('Indiquez le nom de votre personnage')
                    end
                })
                RageUI.Button('Taille du personnage', nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onSelected = function()
                        Creator.height = KeyboardInput('Indiquez le nom de votre personnage')
                    end
                })
                RageUI.Button('~o~Retour à la création', nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onSelected = function()
                        RageUI.GoBack()
                    end
                })
            end)

            RageUI.IsVisible(MainSkin, function()
                Cam()
                RageUI.List('Sexe', Creator.sex.items, Creator.sex.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.sex.index = Index;
                        -- TriggerEvent("skinchanger:change", "sex", Index)
                    end,
                    onSelected = function(u)
                        changeGender(u)
                    end
                })


                
                RageUI.List('Visage', Creator.face.items, Creator.face.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.face.index = Index;
                        TriggerEvent("skinchanger:change", "face", Index)
                    end
                })

                RageUI.List('Peau', Creator.skin.items, Creator.skin.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.skin.index = Index;
                        TriggerEvent("skinchanger:change", "skin", Index)
                    end
                })                

                RageUI.List("Cheveux", Creator.hair_1.items, Creator.hair_1.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.hair_1.index = Index;
                        TriggerEvent("skinchanger:change", "hair_1", Index)
                    end
                })
                
                RageUI.List('Barbe', Creator.beard_1.items, Creator.beard_1.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.beard_1.index = Index;
                        TriggerEvent("skinchanger:change", "beard_1", Index)
                    end
                })

                RageUI.List('Maquillage', Creator.makeup_1.items, Creator.makeup_1.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.makeup_1.index = Index;
                        TriggerEvent("skinchanger:change", "makeup_1", Creator.makeup_1.index)
                    end
                })

                RageUI.List('Rouge à levre', Creator.lipstick_1.items, Creator.lipstick_1.index, nil, {}, true, {
                    onListChange = function(Index)
                        Creator.lipstick_1.index = Index;
                        TriggerEvent("skinchanger:change", "lipstick_1", Creator.lipstick_1.index)
                    end
                })

                RageUI.Button('Finir sa création', nil, {
                    LeftBadge = RageUI.BadgeStyle.Star,
                    Color = {
                        HightLightColor = {148, 0, 255, 150},
                        BackgroundColor = {148, 0, 255, 150}
                    }
                }, true, {
                    onSelected = function()
                        RageUI.GoBack()
                    end
                })
            end, function()
                RageUI.ColourPanel("Couleur Cheveux", RageUI.PanelColour.HairCut, Creator.hair_color.primary[1], Creator.hair_color.primary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.hair_color.primary[1] = MinimumIndex
                        Creator.hair_color.primary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "hair_color_1", Creator.hair_color.primary[2])
                    end
                }, 4)
                RageUI.ColourPanel("Couleur Cheveux 2", RageUI.PanelColour.HairCut, Creator.hair_color.secondary[1], Creator.hair_color.secondary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.hair_color.secondary[1] = MinimumIndex
                        Creator.hair_color.secondary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "hair_color_2", Creator.hair_color.secondary[2])
                    end
                }, 4)

                -------------------------------------------------------

                RageUI.PercentagePanel(Creator.beard_2.percentage, 'Opacité', '0%', '100%', {
                    onProgressChange = function(Percentage)
                        Creator.beard_2.percentage = Percentage
                        TriggerEvent("skinchanger:change", "beard_2", Creator.beard_2.percentage * 10)
                    end
                }, 5);
                RageUI.ColourPanel("Couleur Barbe 1", RageUI.PanelColour.HairCut, Creator.beard_3.primary[1], Creator.beard_3.primary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.beard_3.primary[1] = MinimumIndex
                        Creator.beard_3.primary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "beard_3", Creator.beard_3.primary[2])
                    end
                }, 5)
                RageUI.ColourPanel("Couleur Barbe 2", RageUI.PanelColour.HairCut, Creator.beard_3.secondary[1], Creator.beard_3.secondary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.beard_3.secondary[1] = MinimumIndex
                        Creator.beard_3.secondary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "beard_4", Creator.beard_3.secondary[2])
                    end
                }, 5)

                -------------------------------------------------------

                RageUI.PercentagePanel(Creator.makeup_2.percentage, 'Opacité', '0%', '100%', {
                    onProgressChange = function(Percentage)
                        Creator.makeup_2.percentage = Percentage
                        TriggerEvent("skinchanger:change", "makeup_2", Creator.makeup_2.percentage * 10)
                    end
                }, 6);
                RageUI.ColourPanel("Couleur Maquillage 1", RageUI.PanelColour.HairCut, Creator.makeup_3.primary[1], Creator.makeup_3.primary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.makeup_3.primary[1] = MinimumIndex
                        Creator.makeup_3.primary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "makeup_3", Creator.makeup_3.primary[2])
                    end
                }, 6)
                RageUI.ColourPanel("Couleur Maquillage 2", RageUI.PanelColour.HairCut, Creator.makeup_3.secondary[1], Creator.makeup_3.secondary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.makeup_3.secondary[1] = MinimumIndex
                        Creator.makeup_3.secondary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "makeup_4", Creator.makeup_3.secondary[2])
                    end
                }, 6)
                RageUI.ColourPanel("Couleur Maquillage 3", RageUI.PanelColour.HairCut, Creator.makeup_3.third[1], Creator.makeup_3.third[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.makeup_3.third[1] = MinimumIndex
                        Creator.makeup_3.third[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "makeup_4", Creator.makeup_3.third[2])
                    end
                }, 6)

                -------------------------------------------------------

                RageUI.PercentagePanel(Creator.lipstick_2.percentage, 'Opacité', '0%', '100%', {
                    onProgressChange = function(Percentage)
                        Creator.lipstick_2.percentage = Percentage
                        TriggerEvent("skinchanger:change", "lipstick_2", Creator.lipstick_2.percentage * 10)
                    end
                }, 7);
                RageUI.ColourPanel("Couleur Rouge à levre 1", RageUI.PanelColour.HairCut, Creator.lipstick_3.primary[1], Creator.lipstick_3.primary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.lipstick_3.primary[1] = MinimumIndex
                        Creator.lipstick_3.primary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "lipstick_3", Creator.lipstick_3.primary[2])
                    end
                }, 7)
                RageUI.ColourPanel("Couleur Rouge à levre 2", RageUI.PanelColour.HairCut, Creator.lipstick_3.secondary[1], Creator.lipstick_3.secondary[2], {
                    onColorChange = function(MinimumIndex, CurrentIndex)
                        Creator.lipstick_3.secondary[1] = MinimumIndex
                        Creator.lipstick_3.secondary[2] = CurrentIndex
                        TriggerEvent("skinchanger:change", "lipstick_3", Creator.lipstick_3.secondary[2])
                    end
                }, 7)
            end)

            RageUI.IsVisible(MainStarter, function()
                RageUI.Button("Starter ~g~Légal~s~", nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onActive = function()
                        RageUI.Info('Starter ~g~Légal~s~', {'Argent Liquide :', 'Argent Banque :', 'Object :'}, {'~g~1.000$~s~', '~b~2.500$', '~b~5x~s~ Eau | ~b~5x~s~ Pain'})
                    end,
                    onSelected = function()
                        Creator.starter = {name = "legal", label = "~g~Légal~s~"}
                    end
                })
                RageUI.Button("Starter ~r~Illégale~s~", nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                    onActive = function()
                        RageUI.Info('Starter ~r~Illégal', {'Argent Sale :', 'Argent Banque :', 'Object :'}, {'~r~2.500$~s~', '~b~1.000$', '~b~1x~s~ Bat de Baseball'})
                    end,
                    onSelected = function()
                        Creator.starter = {name = "illegal", label = "~g~Illégal~s~"}
                    end
                })
            end)

            RageUI.IsVisible(MainSpawn, function()
                for k,v in pairs(Spawn) do
                    RageUI.Button(k, nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                        onSelected = function()
                            Creator.spawn = k
                        end
                    })
                end
            end)

            RageUI.IsVisible(MainVetement, function()
                for k,v in pairs(Skin) do
                    RageUI.Button(k, nil, {LeftBadge = RageUI.BadgeStyle.Star}, true, {
                        onSelected = function()
                            Creator.skinSpawn = k
                            setSkinToPed(v)
                        end
                    })
                end
            end)
        end
    end)
end

vector3(237.27, -407.45, 47.92)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local ControlDisable = {20, 24, 27, 178, 177, 189, 190, 187, 188, 202, 239, 240, 201, 172, 173, 174, 175}
function Cam()
    DisableAllControlActions(0)
    for k, v in pairs(ControlDisable) do
        EnableControlAction(0, v, true)
    end
    local Control1, Control2 = IsDisabledControlPressed(1, 44), IsDisabledControlPressed(1, 51)
    local Control3, Control4 = IsDisabledControlPressed(1, 73), IsDisabledControlPressed(1, 79)
    if Control1 or Control2 then
        local pPed = PlayerPedId()
        SetEntityHeading(pPed, Control1 and GetEntityHeading(pPed) - 2.0 or Control2 and GetEntityHeading(pPed) + 2.0)

        for k, v in pairs(GetActivePlayers()) do 
            if v ~= GetPlayerIndex() then 
                NetworkConcealPlayer(v, true, true) 
            end 
        end
    elseif Control3 then
        SetCamFov(cam, GetCamFov(cam) + 0.4)
    elseif Control4 then
        SetCamFov(cam, GetCamFov(cam) - 0.4)
    end
end

function DestroyCamCreator()
    DestroyCam(cam, false)
    RenderScriptCams(false, true, 1500, false, false)
end

function CamCreator(camType)
    SetEntityInvincible(PlayerPedId(), true) 
    FreezeEntityPosition(PlayerPedId(), true) 
    SetEntityCoords(PlayerPedId(), 236.39, -409.29, 46.92)
    SetEntityHeading(PlayerPedId(), 325.98)
    cam = CreateCam("DEFAULT_SCRIPTED_CAMERA", false)
    SetCamActive(cam, true)
    PointCamAtEntity(cam, PlayerPedId(), 0, 0, 0, 1)
    SetCamParams(cam, 238.79, -402.96, 49.92, 2.0, 0.0, 129.0322265625, 70.2442, 0, 1, 1, 2)
    SetCamFov(cam, 25.0)
    RenderScriptCams(1, 0, 0, 1, 1)
end

function setSkinToPed(Tenues)
    TriggerEvent("skinchanger:getSkin", function(skin)
        local uniformObject
        if skin.sex == 0 then
            uniformObject = Tenues.Male
        else
            uniformObject = Tenues.Female
        end
        if uniformObject then
            TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
            TriggerServerEvent('esx_skin:save', skin)
            TriggerEvent('skinchanger:getSkin', function(skin4)
                TriggerServerEvent('skin:save', skin4)
            end)
        end
    end)
end

function skinAnim(coords)
    CinemaMode = true
    TaskGoStraightToCoord(PlayerPedId(), coords, 1.0, 8000, 320.25466, 5)
    CinemaMode = false
end

function GetComponents()
    for i= 0, 45, 1 do
        table.insert(Creator.face.items, '#'..i)
    end
    -------------------------------------------------------
    for i= 0, 210, 1 do
        table.insert(Creator.hair_1.items, '#'..i)
    end
    -------------------------------------------------------
    for i= 0, 100, 1 do
        table.insert(Creator.beard_1.items, '#'..i)
    end
    -------------------------------------------------------
    for i= 0, 45, 1 do
        table.insert(Creator.skin.items, '#'..i)
    end
    -------------------------------------------------------
    for i= 0, 150, 1 do
        table.insert(Creator.makeup_1.items, '#'..i)
    end
    -------------------------------------------------------
    for i= 0, 150, 1 do
        table.insert(Creator.lipstick_1.items, '#'..i)
    end
end

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------