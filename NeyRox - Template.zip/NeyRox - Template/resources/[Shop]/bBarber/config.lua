Config = {}

------------------------------POSITIONS DRAWMARKERS

Config.positionbarber = {
    {position = vector3(-814.3, -183.8, 36.6+1)},
    {position = vector3(136.8, -1708.4, 28.3+1)},
    {position = vector3(-1282.6, -1116.8, 6.0+1)},
    {position = vector3(1931.5, 3729.7, 31.8+1)},
    {position = vector3(-278.1, 6228.5, 30.7+1)},
    {position = vector3(-32.90, -152.66, 56.07+1)},
}

------------------------------POSITIONS/CONFIG BLIPS

Config.blipsBarber = {
    {title="[Auto] Coiffeur", colour=64, id=71, x = -814.3, y = -183.8, z = 36.6},
    {title="[Auto] Coiffeur", colour=64, id=71, x = 136.8, y = -1708.4, z = 28.3},
    {title="[Auto] Coiffeur", colour=64, id=71, x = -1282.6, y = -1116.8, z = 6.0},
    {title="[Auto] Coiffeur", colour=64, id=71, x = 1931.5, y = 3729.7, z = 31.8},
    {title="[Auto] Coiffeur", colour=64, id=71, x = -278.1, y = 6228.5, z = 30.7},
    {title="[Auto] Coiffeur", colour=64, id=71, x = -32.90, y = -152.66, z = 57.07},
}
