Config = {}
Config.Locale = 'fr'